package com.toqueauto.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private val BG = "#0D1512"
    private val CARD = "#16221E"
    private val INK = "#E8F1ED"
    private val MUT = "#8DA19A"
    private val ACC = "#2DD4BF"
    private val ACCINK = "#062B26"
    private val WARN = "#FB923C"
    private val SEC = "#27382F"

    private lateinit var ovTv: TextView
    private lateinit var acTv: TextView
    private lateinit var seqBox: LinearLayout
    private lateinit var ivEt: EditText
    private lateinit var rpEt: EditText
    private lateinit var swEt: EditText
    private lateinit var tmEt: EditText
    private lateinit var txtEt: EditText
    private lateinit var adCb: CheckBox
    private lateinit var lpCb: CheckBox

    private fun d(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: String, r: Int = 14) = GradientDrawable().apply {
        setColor(Color.parseColor(color)); cornerRadius = d(r).toFloat()
    }

    private fun tv(t: String, size: Float, color: String, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun btn(label: String, fill: String, ink: String, a: () -> Unit) = Button(this).apply {
        text = label; setAllCaps(false); textSize = 16f; setTextColor(Color.parseColor(ink))
        background = shape(fill, 12); setPadding(d(12), d(12), d(12), d(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(8) }
        setOnClickListener { a() }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(CARD)
        setPadding(d(14), d(14), d(14), d(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = d(12) }
    }

    private fun field(value: String) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER; setText(value)
        setTextColor(Color.parseColor(INK)); background = shape(BG, 10)
        setPadding(d(12), d(10), d(12), d(10))
    }

    private fun check(label: String, on: Boolean) = CheckBox(this).apply {
        text = label; isChecked = on; setTextColor(Color.parseColor(INK))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(16), d(44), d(16), d(24))
        }
        root.addView(tv("ToqueAuto", 30f, INK, true))
        root.addView(tv("Toques e arrastes automáticos na tela", 14f, MUT).apply { setPadding(0, 0, 0, d(16)) })

        val c1 = card()
        ovTv = tv("", 16f, INK)
        acTv = tv("", 16f, INK)
        c1.addView(ovTv)
        c1.addView(acTv)
        c1.addView(btn("Permitir sobreposição na tela", SEC, INK) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        c1.addView(btn("Ativar acessibilidade do ToqueAuto", SEC, INK) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(c1)

        val c2 = card()
        c2.addView(tv("Intervalo entre ações (ms, mínimo 100)", 14f, MUT))
        ivEt = field(p.getInt("iv", 500).toString())
        c2.addView(ivEt)
        c2.addView(tv("Repetições da sequência (0 = sem limite)", 14f, MUT).apply { setPadding(0, d(10), 0, 0) })
        rpEt = field(p.getInt("rp", 0).toString())
        c2.addView(rpEt)
        c2.addView(tv("Duração de cada arraste (ms)", 14f, MUT).apply { setPadding(0, d(10), 0, 0) })
        swEt = field(p.getInt("sw", 300).toString())
        c2.addView(swEt)
        c2.addView(tv("Parar após (segundos, 0 = sem limite)", 14f, MUT).apply { setPadding(0, d(10), 0, 0) })
        tmEt = field(p.getInt("tm", 0).toString())
        c2.addView(tmEt)
        adCb = check("Anti-detecção (varia o ritmo e a posição)", p.getBoolean("ad", false))
        c2.addView(adCb)
        root.addView(c2)

        val c5 = card()
        c5.addView(tv("Lista de textos para colar (um por linha)", 16f, INK, true))
        txtEt = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4; gravity = Gravity.TOP or Gravity.START
            setText(p.getString("texts", "") ?: "")
            setTextColor(Color.parseColor(INK)); background = shape(BG, 10)
            setPadding(d(12), d(10), d(12), d(10))
        }
        c5.addView(txtEt)
        lpCb = check("Voltar ao início quando a lista acabar", p.getBoolean("lp", false))
        c5.addView(lpCb)
        c5.addView(tv("No modo vários alvos, toque em T na barra flutuante e ponha o círculo roxo sobre o campo de texto. Cada rodada cola uma linha. Depois adicione um toque no botão de enviar.", 13f, MUT))
        root.addView(c5)

        val c3 = card()
        c3.addView(btn("Ativar alvo único", ACC, ACCINK) { go("single", null) })
        c3.addView(btn("Ativar vários alvos", ACC, ACCINK) { go("multi", null) })
        root.addView(c3)

        val c4 = card()
        c4.addView(tv("Sequências salvas", 18f, INK, true))
        seqBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c4.addView(seqBox)
        root.addView(c4)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor(BG))
            addView(root)
        })
    }

    private fun go(mode: String, seq: String?) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Falta permitir a sobreposição.", Toast.LENGTH_LONG).show(); return
        }
        if (ClickService.instance == null) {
            Toast.makeText(this, "Falta ativar a acessibilidade.", Toast.LENGTH_LONG).show(); return
        }
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .putInt("iv", ivEt.text.toString().toIntOrNull() ?: 500)
            .putInt("rp", rpEt.text.toString().toIntOrNull() ?: 0)
            .putInt("sw", swEt.text.toString().toIntOrNull() ?: 300)
            .putInt("tm", tmEt.text.toString().toIntOrNull() ?: 0)
            .putBoolean("ad", adCb.isChecked)
            .putBoolean("lp", lpCb.isChecked)
            .putString("texts", txtEt.text.toString())
            .apply()
        val i = Intent(this, OverlayService::class.java).putExtra("mode", mode)
        if (seq != null) i.putExtra("seq", seq)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        moveTaskToBack(true)
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val ac = ClickService.instance != null
        ovTv.text = "● Sobreposição na tela: " + (if (ov) "ok" else "falta")
        ovTv.setTextColor(Color.parseColor(if (ov) ACC else WARN))
        acTv.text = "● Acessibilidade: " + (if (ac) "ok" else "falta")
        acTv.setTextColor(Color.parseColor(if (ac) ACC else WARN))
        refreshSeqs()
    }

    private fun refreshSeqs() {
        seqBox.removeAllViews()
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val all = JSONObject(p.getString("seqs", "{}") ?: "{}")
        if (all.length() == 0) {
            seqBox.addView(tv("Nenhuma ainda. Na barra flutuante, toque em 💾 para salvar os alvos atuais.", 14f, MUT).apply {
                setPadding(0, d(6), 0, 0)
            })
            return
        }
        val keys = all.keys()
        while (keys.hasNext()) {
            val name = keys.next()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, d(6), 0, 0)
            }
            row.addView(tv(name, 16f, INK).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
            row.addView(btn("Usar", ACC, ACCINK) { go("multi", name) }.apply {
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { leftMargin = d(6) }
            })
            row.addView(btn("Apagar", SEC, INK) {
                val cur = JSONObject(p.getString("seqs", "{}") ?: "{}")
                cur.remove(name)
                p.edit().putString("seqs", cur.toString()).apply()
                refreshSeqs()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { leftMargin = d(6) }
            })
            seqBox.addView(row)
        }
    }
}
