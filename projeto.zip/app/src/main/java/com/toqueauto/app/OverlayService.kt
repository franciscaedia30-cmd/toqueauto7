package com.toqueauto.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class OverlayService : Service() {
    private class Step(val a: TextView, val b: TextView?, val paste: Boolean = false)

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var bar: LinearLayout? = null
    private lateinit var playBtn: TextView
    private val steps = mutableListOf<Step>()
    private var running = false
    private var idx = 0
    private var multi = false
    private var interval = 500L
    private var reps = 0
    private var swipeMs = 300
    private var timeLimit = 0L
    private var t0 = 0L
    private var anti = false
    private var loopList = false
    private var lines: List<String> = emptyList()
    private var lineIdx = 0

    private val stepRun = object : Runnable {
        override fun run() {
            if (!running) return
            val svc = ClickService.instance
            if (svc == null || steps.isEmpty()) { stop(); return }
            if (timeLimit > 0 && System.currentTimeMillis() - t0 >= timeLimit) { stop(); return }
            val s = steps[idx % steps.size]
            val c1 = center(s.a)
            val j = if (anti) (Math.random() * 12 - 6).toFloat() else 0f
            val end = s.b
            var wait = interval
            if (s.paste) {
                val line = nextLine()
                if (line == null) {
                    Toast.makeText(this@OverlayService, "A lista de textos terminou.", Toast.LENGTH_SHORT).show()
                    stop(); return
                }
                svc.tap(c1.first + j, c1.second + j)
                h.postDelayed({ if (running) svc.pasteText(line) }, 400)
                wait = maxOf(interval, 700L)
            } else if (end == null) {
                svc.tap(c1.first + j, c1.second + j)
            } else {
                val c2 = center(end)
                svc.swipe(c1.first, c1.second, c2.first, c2.second, swipeMs.toLong())
                wait = maxOf(interval, swipeMs + 50L)
            }
            idx++
            if (reps > 0 && idx >= reps * steps.size) { stop(); return }
            if (anti) wait = (wait * (0.8 + Math.random() * 0.4)).toLong()
            h.postDelayed(this, wait)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        startFg()
        cleanup()
        val seq = i?.getStringExtra("seq")
        multi = seq != null || i?.getStringExtra("mode") == "multi"
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        interval = maxOf(100, p.getInt("iv", 500)).toLong()
        reps = p.getInt("rp", 0)
        swipeMs = maxOf(50, p.getInt("sw", 300))
        timeLimit = maxOf(0, p.getInt("tm", 0)) * 1000L
        anti = p.getBoolean("ad", false)
        loopList = p.getBoolean("lp", false)
        lines = (p.getString("texts", "") ?: "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        buildBar()
        if (seq != null) loadSeq(seq)
        if (steps.isEmpty()) newTap()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val chan = "toqueauto"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(chan, "ToqueAuto", NotificationManager.IMPORTANCE_LOW))
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, chan) else Notification.Builder(this)
        val n = nb.setContentTitle("ToqueAuto ativo")
            .setContentText("Toque para abrir as configurações")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun params(w: Int, ht: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, ht, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun center(v: View): Pair<Float, Float> {
        val p = v.layoutParams as WindowManager.LayoutParams
        return Pair(p.x + v.width / 2f, p.y + v.height / 2f)
    }

    private fun button(t: String, a: () -> Unit) = TextView(this).apply {
        text = t; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        layoutParams = LinearLayout.LayoutParams(dp(42), dp(40))
        setOnClickListener { a() }
    }

    private fun buildBar() {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E616221E")); cornerRadius = dp(14).toFloat()
            }
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        playBtn = button("▶") { toggle() }
        b.addView(playBtn)
        b.addView(button("+") { newTap() })
        b.addView(button("↔") { newSwipe() })
        b.addView(button("T") { newPaste() })
        b.addView(button("−") { removeStep() })
        b.addView(button("💾") { saveSeq() })
        b.addView(button("⚙") {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        val mv = button("✥") {}
        b.addView(mv)
        b.addView(button("✕") { stopSelf() })
        wm.addView(b, params(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, dp(8), dp(120)))
        makeDraggable(mv, b)
        bar = b
    }

    private fun circle(label: String, color: String) = TextView(this).apply {
        text = label; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#80" + color))
            setStroke(dp(3), Color.parseColor("#" + color))
        }
    }

    private fun addTap(x: Int, y: Int) {
        val a = circle((steps.size + 1).toString(), "2DD4BF")
        wm.addView(a, params(dp(52), dp(52), x, y))
        makeDraggable(a, a)
        steps.add(Step(a, null))
    }

    private fun addSwipe(x: Int, y: Int, x2: Int, y2: Int) {
        val a = circle((steps.size + 1).toString(), "2DD4BF")
        val b = circle("→", "FB923C")
        wm.addView(a, params(dp(52), dp(52), x, y))
        wm.addView(b, params(dp(52), dp(52), x2, y2))
        makeDraggable(a, a)
        makeDraggable(b, b)
        steps.add(Step(a, b))
    }

    private fun newTap() {
        if (!multi && steps.isNotEmpty()) return
        val n = steps.size % 5
        addTap(dp(100) + n * dp(56), dp(300) + n * dp(40))
    }

    private fun newSwipe() {
        if (!multi) {
            Toast.makeText(this, "Arrastar só no modo vários alvos.", Toast.LENGTH_SHORT).show(); return
        }
        val n = steps.size % 5
        val x = dp(100) + n * dp(56)
        val y = dp(300) + n * dp(40)
        addSwipe(x, y, x, y + dp(160))
    }

    private fun addPaste(x: Int, y: Int) {
        val a = circle((steps.size + 1).toString() + "T", "A78BFA")
        wm.addView(a, params(dp(52), dp(52), x, y))
        makeDraggable(a, a)
        steps.add(Step(a, null, true))
    }

    private fun newPaste() {
        if (!multi) {
            Toast.makeText(this, "Colar texto só no modo vários alvos.", Toast.LENGTH_SHORT).show(); return
        }
        val n = steps.size % 5
        addPaste(dp(100) + n * dp(56), dp(300) + n * dp(40))
    }

    private fun removeStep() {
        if (running) return
        val s = steps.removeLastOrNull() ?: return
        wm.removeView(s.a)
        s.b?.let { wm.removeView(it) }
    }

    private fun saveSeq() {
        if (steps.isEmpty()) return
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val all = JSONObject(p.getString("seqs", "{}") ?: "{}")
        val n = p.getInt("seqn", 0) + 1
        val name = "Sequência $n"
        val arr = JSONArray()
        for (s in steps) {
            val pa = s.a.layoutParams as WindowManager.LayoutParams
            val o = JSONObject().put("x", pa.x).put("y", pa.y)
            if (s.paste) o.put("p", true)
            val end = s.b
            if (end != null) {
                val pb = end.layoutParams as WindowManager.LayoutParams
                o.put("x2", pb.x).put("y2", pb.y)
            }
            arr.put(o)
        }
        all.put(name, arr)
        p.edit().putString("seqs", all.toString()).putInt("seqn", n).apply()
        Toast.makeText(this, "Salvo: $name", Toast.LENGTH_SHORT).show()
    }

    private fun loadSeq(name: String) {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val all = JSONObject(p.getString("seqs", "{}") ?: "{}")
        val arr = all.optJSONArray(name) ?: return
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optBoolean("p")) addPaste(o.getInt("x"), o.getInt("y"))
            else if (o.has("x2")) addSwipe(o.getInt("x"), o.getInt("y"), o.getInt("x2"), o.getInt("y2"))
            else addTap(o.getInt("x"), o.getInt("y"))
        }
    }

    private fun makeDraggable(handle: View, target: View) {
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        handle.setOnTouchListener { _, e ->
            val p = target.layoutParams as WindowManager.LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - dx).toInt()
                    p.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(target, p)
                }
            }
            true
        }
    }

    private fun setTouchable(on: Boolean) {
        val views = mutableListOf<View>()
        for (s in steps) { views.add(s.a); s.b?.let { views.add(it) } }
        for (t in views) {
            val p = t.layoutParams as WindowManager.LayoutParams
            p.flags = if (on) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(t, p)
        }
    }

    private fun nextLine(): String? {
        if (lines.isEmpty()) return null
        if (lineIdx >= lines.size) {
            if (loopList) lineIdx = 0 else return null
        }
        return lines[lineIdx++]
    }

    private fun toggle() { if (running) stop() else start() }

    private fun start() {
        if (steps.isEmpty()) return
        running = true; idx = 0; lineIdx = 0; t0 = System.currentTimeMillis(); playBtn.text = "■"
        setTouchable(false)
        h.post(stepRun)
    }

    private fun stop() {
        running = false; h.removeCallbacks(stepRun); playBtn.text = "▶"
        setTouchable(true)
    }

    private fun cleanup() {
        running = false; h.removeCallbacks(stepRun)
        for (s in steps) {
            try { wm.removeView(s.a) } catch (e: Exception) {}
            s.b?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        }
        steps.clear()
        bar?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bar = null
    }

    override fun onDestroy() {
        cleanup()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
